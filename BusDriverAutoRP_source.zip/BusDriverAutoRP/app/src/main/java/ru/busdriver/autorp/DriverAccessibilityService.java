package ru.busdriver.autorp;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

public class DriverAccessibilityService extends AccessibilityService {
    private static DriverAccessibilityService instance;
    private static volatile boolean stopped = true;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopped = true; }

    @Override public void onDestroy() {
        if (instance == this) instance = null;
        stopped = true;
        super.onDestroy();
    }

    public static boolean tapCenter() {
        DriverAccessibilityService s = instance;
        if (s == null) return false;
        stopped = false;
        s.dispatchTap();
        return true;
    }

    public static void stop() { stopped = true; }

    private void dispatchTap() {
        if (stopped) return;
        float x = getResources().getDisplayMetrics().widthPixels / 2f;
        float y = getResources().getDisplayMetrics().heightPixels / 2f;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path, 0, 80);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(stroke);
        dispatchGesture(builder.build(), null, new Handler(Looper.getMainLooper()));
    }
}
