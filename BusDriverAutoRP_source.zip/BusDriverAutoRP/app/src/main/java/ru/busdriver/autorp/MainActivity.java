package ru.busdriver.autorp;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("BusDriver Auto RP");
        title.setTextSize(26);
        title.setTextColor(0xFFFFFFFF);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("\nПрототип для Infinix HOT 50 / Android 14.\n\nСейчас доступна проверка Accessibility и тестовое касание. Полный автопилот маршрута ещё не настроен: для него нужны точные кадры/координаты поворотов и проверка обратного пути.");
        info.setTextSize(16);
        info.setTextColor(0xFFD8E2EA);
        root.addView(info);

        Button settings = button("1. Включить службу управления");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(settings);

        Button test = button("2. Проверить касание по центру экрана");
        test.setOnClickListener(v -> {
            boolean ok = DriverAccessibilityService.tapCenter();
            status.setText(ok ? "Команда отправлена. Проверь, появилось ли касание." :
                "Служба не включена. Включи её в настройках Android и вернись сюда.");
        });
        root.addView(test);

        Button stop = button("СТОП / сброс");
        stop.setOnClickListener(v -> {
            DriverAccessibilityService.stop();
            status.setText("Команды остановлены.");
        });
        root.addView(stop);

        status = new TextView(this);
        status.setText("\nСтатус: ожидание");
        status.setTextColor(0xFF80CBC4);
        status.setTextSize(16);
        root.addView(status);

        setContentView(root);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 18, 0, 0);
        b.setLayoutParams(p);
        return b;
    }
}
